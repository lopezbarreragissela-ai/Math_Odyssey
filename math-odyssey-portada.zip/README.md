# Math Odyssey 📊📐

**Math Odyssey** es un laboratorio educativo interactivo de **Estadística Descriptiva y Frecuencias en 3D** desarrollado en **HTML5, CSS3, JavaScript, Three.js, KaTeX y MediaPipe**, que transforma listas de datos numéricos en tablas de frecuencias (simples y acumuladas), gráficas tridimensionales interactivas, fórmulas matemáticas profesionales e interpretaciones automáticas.

---

## 🎯 Funcionalidades Principales

### 1. Panel Izquierdo — Datos, Orden, Agrupación y Menú de Gráficas
* **Entrada libre de datos numéricos**: Ingresa números enteros o decimales separados por comas, espacios o saltos de línea (incluye ejemplos rápidos).
* **Ordenamiento automático con inversión**: Organiza los datos de **menor a mayor** por defecto, con botón para invertir el orden a **mayor a menor** resaltando mínimo y máximo.
* **Conversión a Datos Agrupados**: Cuando el conjunto tiene tamaño y variabilidad suficientes (\(n \ge 5\), rango \(> 0\) y al menos 4 valores distintos), permite agrupar por intervalos usando la **Regla de Sturges** \(k = 1 + 3.322 \log_{10}(n)\) con control manual de intervalos.
* **Menú de Gráficas de Frecuencias 3D**:
  * **Barras / Histograma 3D** (\(f_i\))
  * **Polígono de Frecuencias 3D**
  * **Gráfica Circular / Pastel 3D** (\(\%\))
  * **Ojiva Acumulada 3D** (\(F_i\) con línea de referencia de la mediana al 50%)
  * **Columnas Cilíndricas 3D**

### 2. Panel Central — Visor 3D + Tabla de Frecuencias
* **Visor interactivo Three.js**: Modos Sólido PBR, Malla de Alambre y Rayos X, animación de elevación 0–100%, resaltado de la clase modal y selección directa al hacer clic en filas de la tabla.
* **Tabla de Frecuencias extensible**: Muestra \(x_i\) (o intervalos y marca de clase), \(f_i\), \(h_i\) y \(\%\), con botón dedicado para **extender a Frecuencias Acumuladas** (\(F_i\), \(H_i\), \(F\%\)).

### 3. Panel Derecho — Estadísticos, Fórmulas KaTeX e Interpretaciones
* **Medidas de Tendencia Central**: Media (\(\bar{x}\)), Mediana (\(Me\)) y Moda (\(Mo\)).
* **Medidas de Dispersión, Posición y Forma**: Rango (\(R\)), Mínimo/Máximo, Varianza (\(s^2\)), Desviación Estándar (\(s\)), Coeficiente de Variación (\(CV\%\)), Cuartiles (\(Q_1, Q_3\)), Rango Intercuartílico (\(IQR\)), Asimetría (\(g_1\)) y Suma (\(\sum x_i\)).
* **Fórmulas Profesionales en KaTeX**: Ecuaciones no lineales con sustitución dinámica adaptadas a datos no agrupados y agrupados.
* **Interpretaciones Estadísticas Automáticas**: Lectura clara de centro, homogeneidad/dispersión, forma/asimetría, concentración central, posibles valores atípicos y lectura de frecuencias.

---

## ✋ Control Gestual con MediaPipe Hands y Modo RA

La aplicación mantiene habilitada la manipulación por gestos con **Google MediaPipe Hands** y la superposición de cámara web (**Modo RA**):

| Gesto | Icono | Acción en la Aplicación |
| :--- | :---: | :--- |
| **Palma abierta** | ✋ | Rotar libremente la gráfica 3D en el espacio. |
| **Índice levantado** | ☝️ | Alternar Animar / Pausar la elevación 3D. |
| **Pinza pulgar + índice** | 👌 | Controlar con precisión el nivel de elevación (0% a 100%). |
| **Dos manos** | 🙌 | Acercar o alejar la cámara (Zoom interactivo). |
| **Puño cerrado** | ✊ | Restablecer la cámara y el ángulo de visión original. |

Además incluye un **Simulador de Gestos** integrado para probar cada acción con un clic sin cámara web.

---

## 🚀 Instrucciones de Ejecución

### Entorno Local (Node.js / Vite)
```bash
npm install
npm run dev
```
Disponible en `http://localhost:3000`. También puede abrirse directamente en **XAMPP** o **GitHub Pages** como archivo estático `index.html`.

